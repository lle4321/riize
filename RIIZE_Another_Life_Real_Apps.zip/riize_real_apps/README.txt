RIIZE Another Life — distinct social app mockups

How to publish on your existing GitHub Pages repo:
1. Open https://github.com/lle4321/riize
2. Open index.html and click Edit (pencil), replace all content with the provided index.html, then Commit changes.
   Or Add file -> Upload files and upload this index.html, confirming replacement.
3. Ensure Settings -> Pages uses main branch and /(root).
4. Wait for deployment, then visit https://lle4321.github.io/riize/

Lock-screen PIN: 0403
Apps have distinct mock interfaces: Instagram-style stories/feed/DM; Weverse community feed/artist chat; X timeline/DM; Threads feed/replies; KakaoTalk yellow-chat style. Chat content is fictional fan-made simulation and does not connect to real accounts. Chat data is kept in memory for this page session.
